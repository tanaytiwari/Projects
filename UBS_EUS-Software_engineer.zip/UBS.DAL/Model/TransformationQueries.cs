﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UBS.DAL.Model
{
   public class TransformationQueries
    {
        public Currency GetTransformation(Currency objectToBeTransformed)
        {
            var convertedCurrency = new Currency();
            using (CurrencyDbNewEntities db = new CurrencyDbNewEntities()) {
                var result = (from item in db.CurrencyMappings
                             where item.CId == objectToBeTransformed.currencyObject.CId && item.CNameTo ==objectToBeTransformed.currencyObject.CName
                             select item).FirstOrDefault();
                if (result != null) {
                    // CurrencyMapping translation = result.First<CurrencyMapping>;
                    int amount = objectToBeTransformed.Amount;
                    Decimal conversionValue = Convert.ToDecimal(result.ConversionValue);
                    convertedCurrency.Amount =  Convert.ToInt32(amount / conversionValue);
                }
                
            }
                return convertedCurrency;

        }
    }
}

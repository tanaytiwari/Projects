﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UBS.DAL.Model
{
  public  class Currency
    {
        public CurrencyMaster currencyObject;
        public int Amount;
    }
}

﻿-- Script Date: 20-09-2019 08:45  - ErikEJ.SqlCeScripting version 3.5.2.81
INSERT INTO [CurrencyMaster] ([CId],[CName],[CountryName],[shortName]) VALUES (
1,'Rupee','India','Rs');
INSERT INTO [CurrencyMaster] ([CId],[CName],[CountryName],[shortName]) VALUES (
2,'Dirham','UAE','Dirham');
INSERT INTO [CurrencyMaster] ([CId],[CName],[CountryName],[shortName]) VALUES (
3,'United States Dollar','USA','USD');
INSERT INTO [CurrencyMaster] ([CId],[CName],[CountryName],[shortName]) VALUES (
4,'Great Britain Pound','Britain','GBP');
INSERT INTO [CurrencyMaster] ([CId],[CName],[CountryName],[shortName]) VALUES (
5,'Yen','Japan','Yen');
INSERT INTO [CurrencyMaster] ([CId],[CName],[CountryName],[shortName]) VALUES (
6,'Euro','Europe','Eu');
INSERT INTO [CurrencyMaster] ([CId],[CName],[CountryName],[shortName]) VALUES (
7,'Rouble','Russia','Rouble');
INSERT INTO [CurrencyMaster] ([CId],[CName],[CountryName],[shortName]) VALUES (
8,'Yuan','China','Yuan');

﻿-- Script Date: 20-09-2019 08:44  - ErikEJ.SqlCeScripting version 3.5.2.81
CREATE TABLE [CurrencyMaster] (
  [CId] INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL
, [CName] text NULL
, [CountryName] text NULL
, [shortName] text NULL
);

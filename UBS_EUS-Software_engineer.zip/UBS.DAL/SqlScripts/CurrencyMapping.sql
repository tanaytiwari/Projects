﻿-- Script Date: 20-09-2019 08:43  - ErikEJ.SqlCeScripting version 3.5.2.81
CREATE TABLE [CurrencyMapping] (
  [CId] INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL
, [CNameFrom] text NOT NULL
, [CNameTo] text NOT NULL
, [ConversionValue] numeric(53,0) NOT NULL
);

﻿-- Script Date: 20-09-2019 08:43  - ErikEJ.SqlCeScripting version 3.5.2.81
INSERT INTO [CurrencyMapping] ([CId],[CNameFrom],[CNameTo],[ConversionValue]) VALUES (
1,'Rs','USD',71.234257);
INSERT INTO [CurrencyMapping] ([CId],[CNameFrom],[CNameTo],[ConversionValue]) VALUES (
3,'USD','Rs',0.014038);

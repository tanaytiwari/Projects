﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using UBS.DAL.Model;
using Humanizer;


namespace TransformationService
{
    class CurrencyTransform :ICurrencyTransform
    {

        public string Humanize(Currency transformationObject)
        {
            TransformationQueries tq = new TransformationQueries();
             var currencyObj =  tq.GetTransformation(transformationObject);
            return currencyObj.Amount.ToWords() ;

        }


        public string GetMessage(string str) {
            return "Hello";
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using UBS.DAL.Model;

namespace TransformationService
{
    [ServiceContract]
    interface ICurrencyTransform
    {
        [OperationContract]
        string Humanize(Currency transformationObject);

        [OperationContract]
        string GetMessage(string str);


    }
}

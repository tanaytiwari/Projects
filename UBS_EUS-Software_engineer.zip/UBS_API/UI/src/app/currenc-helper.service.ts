import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CurrencHelperService {

  constructor(private httpObj : HttpClient) { }
  configUrl="//localhost:61978/api/Currency"

  getCurrencyList(){
    return this.httpObj.get(this.configUrl+"/GetCurrencies");
  }

  saveCurrency(objectToBeSaved:any){
    return this.httpObj.post(this.configUrl+"/Transformation",objectToBeSaved);
  }
}

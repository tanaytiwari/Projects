import { TestBed } from '@angular/core/testing';

import { CurrencHelperService } from './currenc-helper.service';

describe('CurrencHelperService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CurrencHelperService = TestBed.get(CurrencHelperService);
    expect(service).toBeTruthy();
  });
});

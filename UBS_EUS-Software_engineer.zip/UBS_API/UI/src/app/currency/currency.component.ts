import { Component, OnInit } from '@angular/core';
import {CurrencHelperService} from '../currenc-helper.service'


@Component({
  selector: 'app-currency',
  templateUrl: './currency.component.html',
  styleUrls: ['./currency.component.css']
})
export class CurrencyComponent implements OnInit {
  constructor(private currencyService:CurrencHelperService) { 
    this.currencyService.getCurrencyList().subscribe((data:CurrencyMaster[])=>{
      
      this.currencyList=data;
    });
   
  }
  currencyList: CurrencyMaster[];
  selectFrom:number;
  selectTo:string;
  amount:number;
  transformationAmount:string;
  currencyToBeSaved:Currency={
    currencyObject:{ CId: 0,
    CName:'',
    CountryName:'',
    CurrencyShortName:''},
    Amount:0};


      ngOnInit() {
   
          
    }
    submitTransformation(obj1,obj2,obj3){
    debugger;
    
      this.currencyToBeSaved.currencyObject.CId= this.currencyList.filter((item)=>{  return item.CName===obj1.value})[0].CId;
      this.currencyToBeSaved.currencyObject.CName=this.currencyList.filter((item)=>{ return item.CName===obj2.value})[0].CName;
      this.currencyToBeSaved.Amount=obj3.value;
       this.currencyService.saveCurrency(this.currencyToBeSaved).subscribe((data:string)=>{
           this.transformationAmount=data;
           debugger;
       });;
    }
}

class CurrencyMaster{
  CId: number;
  CName:string;
  CountryName:string;
  CurrencyShortName:string;
  
}
class Currency{
   currencyObject:CurrencyMaster;
   Amount:number;
}


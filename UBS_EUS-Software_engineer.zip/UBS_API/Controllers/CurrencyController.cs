﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
using UBS.DAL.Model;
using UBS_API.WCFServiceReferecne;



namespace UBS_API.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class CurrencyController : ApiController
    {

        //localhost:61978/api/Currency/GetCurrencies
        [HttpGet]
        public IEnumerable<CurrencyMaster> GetCurrencies() {
            using (CurrencyDbNewEntities db = new CurrencyDbNewEntities()) {
                return db.CurrencyMasters.ToList();
            }

        }

        //api/Currency/Transformation
        [HttpPost]
        public string Transformation([FromBody]Currency obj) {

            using (CurrencyDbNewEntities db = new CurrencyDbNewEntities())
            {
                var amount = "";
                //Calling WCF service for Currency Conversions
                using (CurrencyTransformClient client = new CurrencyTransformClient()) {
                  amount =   client.Humanize(obj);
                }
                 return amount;
            }
        }

    }
}
